//
//  PaymentSDK.h
//  PaymentSDK
//
//  Created by Adesegun Adeyemo on 9/28/15.
//  Copyright © 2015 Interswitch Limited. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PaymentSDK.
FOUNDATION_EXPORT double PaymentSDKVersionNumber;

//! Project version string for PaymentSDK.
FOUNDATION_EXPORT const unsigned char PaymentSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PaymentSDK/PublicHeader.h>


#import <PaymentSDK/Crypto.h>